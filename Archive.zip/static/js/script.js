function sendMessage() {
    const form = document.getElementById('chat-form');
    const userInput = document.getElementById('user-input').value;
    const fileInput = document.getElementById('image-upload');
    const file = fileInput.files[0];

    // Add user message to chat
    const chatBox = document.getElementById('chat-box');
    let userMessageText = '';
    if (userInput.trim()) {
        userMessageText += userInput;
    }
    if (file) {
        userMessageText += (userMessageText ? '\n' : '') + 'Uploaded an image.';
    }
    if (userMessageText) {
        const userMessage = document.createElement('div');
        userMessage.className = 'message user-message';
        userMessage.innerHTML = userMessageText.replace(/\n/g, '<br>');
        chatBox.appendChild(userMessage);
    }

    // Send message and/or image to server
    const formData = new FormData(form);
    fetch('/chat', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const botMessage = document.createElement('div');
        botMessage.className = 'message bot-message';
        botMessage.innerHTML = data.response.replace(/\n/g, '<br>');
        if (data.image_url) {
            const img = document.createElement('img');
            img.src = data.image_url;
            botMessage.appendChild(img);
        }
        chatBox.appendChild(botMessage);
        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(error => {
        const botMessage = document.createElement('div');
        botMessage.className = 'message bot-message';
        botMessage.textContent = 'Error: ' + error;
        chatBox.appendChild(botMessage);
    });

    // Clear inputs
    document.getElementById('user-input').value = '';
    fileInput.value = '';
}

function submitFeedback(value) {
    const formData = new FormData();
    formData.append('feedback', value);
    fetch('/feedback', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('feedback-status').textContent = data.response;
    })
    .catch(error => {
        document.getElementById('feedback-status').textContent = 'Error submitting feedback: ' + error;
    });
}